// lib/presentation/screens/splash/splash_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:myapp/core/theme/app_colors.dart';
import 'package:myapp/core/theme/text_styles.dart';
import '../../providers/auth/auth_provider.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  
  // أنيميشن لظهور وتكبير الشعار
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  
  // أنيميشن لظهور النص وانزلاقه من الأسفل
  late Animation<double> _textFade;
  late Animation<Offset> _textSlide;

  @override
  void initState() {
    super.initState();
    
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );

    // 1. إعدادات حركة الشعار (تظهر في أول 40% من الوقت)
    _logoScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(0.0, 0.5, curve: Curves.easeOutBack),
      ),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.4, curve: Curves.easeIn),
      ),
    );

    // 2. إعدادات حركة النص (تبدأ بعد ظهور الشعار جزئياً)
    _textFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.5, 0.8, curve: Curves.easeIn),
      ),
    );
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.5, 0.9, curve: Curves.easeOut),
      ),
    );

    _controller.forward();
    _checkAuth();
  }

//  Future<void> _checkAuth() async {
//   // ننتظر انتهاء الأنيميشن أو وقت كافٍ
//   await Future.delayed(const Duration(milliseconds: 3000));

//   if (!mounted) return;

//   final localDataSource = ref.read(authLocalDataSourceProvider);
//   final isAuthenticated = await localDataSource.hasValidToken();

//   if (!mounted) return; // ✅ تحقق من mounted بعد async call

//   if (!isAuthenticated) {
//     if (!mounted) return;
//     context.go('/login');
//     return;
//   }

//   final user = await localDataSource.getCachedUser();

//   if (!mounted) return; // ✅ تحقق من mounted قبل استخدام context
//   if (user == null) {
//     context.go('/login');
//     return;
//   }

//   final role = user.role.toUpperCase();
//   switch (role) {
//     case 'PARENT':
//     case 'GUARDIAN':
//       context.go('/guardian');
//       break;
//     case 'TEACHER':
//       context.go('/teacher');
//       break;
//     case 'MANAGER':
//       context.go('/manager');
//       break;
//     default:
//       context.go('/login');
//   }
// }
 Future<void> _checkAuth() async {
  await Future.delayed(const Duration(milliseconds: 3000));
  if (!mounted) return;

  final localDataSource = ref.read(authLocalDataSourceProvider);
  final isAuthenticated = await localDataSource.hasValidToken();
  if (!mounted) return;

  if (!isAuthenticated) {
    context.go('/login');
    return;
  }

  final user = await localDataSource.getCachedUser();
  if (!mounted) return;

  if (user == null) {
    context.go('/login');
    return;
  }

  final role = user.role.toUpperCase();

  // ✅ اطلب إذن الموقع فقط للـ Guardian/Parent
  // if (role == 'PARENT' || role == 'GUARDIAN') {
  //   final ls = ref.read(locationServiceProvider);

  //   // لا توقف مسار الدخول حتى لو رفض، بس اطلب مرة
  //   await ls.ensurePermission();

  //   // (اختياري) warmup بسيط عشان أول طلب يكون أسرع
  //   await ls.warmUpHighAccuracy();
  // }

  if (!mounted) return;

  switch (role) {
    case 'PARENT':
    case 'GUARDIAN':
      context.go('/guardian');
      break;
    case 'TEACHER':
      context.go('/teacher');
      break;
    case 'MANAGER':
      context.go('/manager');
      break;
    default:
      context.go('/login');
  }
}
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.primary, Color(0xFF1E3C72)], // تدرج لوني احترافي
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // أنيميشن الشعار
            FadeTransition(
              opacity: _logoFade,
              child: ScaleTransition(
                scale: _logoScale,
                child: Container(
                  height: 140,
                  width: 140,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha((0.15 * 255).round()),
                        blurRadius: 30,
                        spreadRadius: 5,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Image.asset(
                    'assets/images/kyan3.png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            
            const SizedBox(height: 30),

            // أنيميشن النص (الظهور المتتابع)
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return FadeTransition(
                  opacity: _textFade,
                  child: SlideTransition(
                    position: _textSlide,
                    child: Column(
                      children: [
                        Text(
                          'الكيان الرقمي',
                          style: AppTextStyles.heading1.copyWith(
                            color: Colors.white,
                            fontSize: 32,
                            letterSpacing: 1.2,
                            shadows: [
                              Shadow(
                                color: Colors.black.withAlpha((0.3 * 255).round()),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          width: 40,
                          height: 3,
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha((0.5 * 255).round()),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}