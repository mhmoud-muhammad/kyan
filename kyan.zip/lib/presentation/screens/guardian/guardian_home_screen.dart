// lib/presentation/screens/guardian/guardian_home_screen.dart
import 'package:flutter/material.dart';
import 'package:myapp/core/errors/exception_mapper.dart';
import 'package:myapp/core/network/connectivity_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:myapp/core/errors/failures.dart';
import 'package:myapp/core/services/location_service.dart';
import 'package:myapp/core/theme/app_colors.dart';
import 'package:myapp/core/theme/text_styles.dart';
import 'package:myapp/domain/entities/school.dart';
import 'package:myapp/domain/entities/student.dart';
import 'package:myapp/domain/entities/user.dart';
import 'package:myapp/presentation/providers/auth/auth_provider.dart';
import 'package:myapp/presentation/providers/guardian/guardian_provider.dart';

class GuardianHomeScreen extends ConsumerWidget {
  const GuardianHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final selectedSchool = ref.watch(selectedSchoolProvider);
    final user = authState.value;
    final isOnline = ref.watch(isOnlineProvider);
    ref.listen(authStateProvider, (previous, next) {
      if (next is AsyncData && next.value == null) {
        if (context.mounted) {
          context.go('/login');
        }
      }
    });
    return PopScope<Object?>(
      canPop: selectedSchool == null, // ✅ امنع الرجوع (الخروج) لو داخل الطلاب
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;

        // ✅ بدل ما يخرج التطبيق: ارجع لقائمة المدارس
        ref.read(selectedSchoolProvider.notifier).clearSelection();
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text(
            selectedSchool == null ? 'مدارسي' : selectedSchool.name,
            style: AppTextStyles.heading2.copyWith(
              fontSize: 18,
              color: AppColors.textPrimary,
            ),
          ),
          centerTitle: true,
          backgroundColor: AppColors.surface,
          foregroundColor: AppColors.textPrimary,
          elevation: 1,
          leading: selectedSchool != null
              ? Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    // ignore: deprecated_member_use
                    color: AppColors.primary.withAlpha((0.1 * 255).round()),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new, size: 20),
                    onPressed: () => ref
                        .read(selectedSchoolProvider.notifier)
                        .clearSelection(),
                  ),
                )
              : Builder(
                  builder: (context) => Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withAlpha((0.1 * 255).round()),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.menu_rounded, size: 24),
                      onPressed: () => Scaffold.of(context).openDrawer(),
                    ),
                  ),
                ),
        ),
        drawer: _AppDrawer(user: user),
        body: SafeArea(
          child: Column(
            children: [
              if (!isOnline)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.shade600,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.wifi_off, color: Colors.white),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'لا يوجد اتصال بالإنترنت — سيتم المحاولة تلقائياً عند عودة الاتصال',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, animation) =>
                      FadeTransition(opacity: animation, child: child),
                  child: selectedSchool == null
                      ? const SchoolSelectionView(key: ValueKey('schools'))
                      : const StudentListView(key: ValueKey('students')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Failure asFailure(Object err) {
  if (err is Failure) return err;
  return mapExceptionToFailure(err);
}

String friendlyFailureMessage(Failure f) {
  if (f is LocationFailure) return f.message;

  if (f is ValidationFailure) {
    if (f.errors.isNotEmpty) return f.errors.values.first;
    return 'البيانات غير صحيحة';
  }

  if (f is UnauthorizedFailure) {
    return 'انتهت الجلسة، يرجى تسجيل الدخول مرة أخرى';
  }

  if (f is NetworkFailure) return f.message;

  // ✅ الحالة العامة لأي خطأ من السيرفر
  return f.message.isNotEmpty
      ? f.message
      : 'حدث خطأ من الخادم. الرجاء المحاولة مرة أخرى.';
}

// ===================================================================
//                        القائمة الجانبية (Drawer)
// ===================================================================
class _AppDrawer extends ConsumerWidget {
  final User? user;
  const _AppDrawer({this.user});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Drawer(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(20)),
      ),
      width: MediaQuery.of(context).size.width * 0.7,
      child: Container(
        color: AppColors.surface,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _buildDrawerHeader(context, user),
            const SizedBox(height: 10),
            _buildDrawerItem(
              icon: Icons.person_outline_rounded,
              title: 'الملف الشخصي',
              color: AppColors.primary,
              onTap: () {
                Navigator.pop(context);
                context.push('/profile');
              },
            ),
            _buildDrawerItem(
              icon: Icons.settings_outlined,
              title: 'الإعدادات',
              color: AppColors.textSecondary,
              onTap: () {
                Navigator.pop(context);
                context.push('/settings');
              },
            ),
            _buildDrawerItem(
              icon: Icons.privacy_tip_outlined,
              title: 'سياسة الخصوصية',
              color: AppColors.primaryDark,
              onTap: () {
                Navigator.pop(context);
                _showPrivacyPolicyDialog(context);
              },
            ),
            const Divider(
              height: 30,
              thickness: 0.5,
              indent: 20,
              endIndent: 20,
            ),
            _buildDrawerItem(
              icon: Icons.logout_rounded,
              title: 'تسجيل الخروج',
              color: AppColors.error,
              onTap: () async {
                debugPrint('1. onTap: بدأ');
                await showLogoutConfirmation(context, ref);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerHeader(BuildContext context, User? user) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primary, AppColors.primaryDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                user?.name ?? 'مستخدم',
                style: const TextStyle(
                  color: AppColors.onPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                user?.phone ?? '',
                style: TextStyle(
                  color: AppColors.onPrimary.withAlpha((0.8 * 255).round()),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required Color color,
  }) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: color.withAlpha((0.1 * 255).round()),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 22),
      ),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
      trailing: Icon(
        Icons.arrow_forward_ios_rounded,
        size: 16,
        color: AppColors.textHint,
      ),
      onTap: onTap,
    );
  }

  // Future<bool?> _showLogoutConfirmationDialog(BuildContext context) {
  //   return showDialog<bool>(
  //     context: context,
  //     builder: (context) => AlertDialog(
  //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
  //       title: const Text('تسجيل الخروج'),
  //       content: const Text('هل أنت متأكد من تسجيل الخروج؟'),
  //       actions: [
  //         TextButton(
  //           onPressed: () => Navigator.pop(context, false),
  //           child: const Text('إلغاء'),
  //         ),
  //         ElevatedButton(
  //           onPressed: () => Navigator.pop(context, true),
  //           style: ElevatedButton.styleFrom(
  //             backgroundColor: AppColors.error,
  //             foregroundColor: AppColors.onPrimary,
  //             shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(10),
  //             ),
  //             padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
  //           ),
  //           child: const Text('تسجيل الخروج'),
  //         ),
  //       ],
  //     ),
  //   );
  // }

  void _showPrivacyPolicyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('سياسة الخصوصية'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'نحن نلتزم بحماية خصوصية معلوماتك الشخصية.',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                '• يتم جمع البيانات الضرورية فقط لتقديم الخدمة\n'
                '• لا يتم مشاركة بياناتك مع أطراف ثالثة دون موافقتك\n'
                '• يمكنك طلب حذف بياناتك في أي وقت\n'
                '• نستخدم إجراءات أمنية لحماية معلوماتك',
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('موافق'),
          ),
        ],
      ),
    );
  }
}

// ===================================================================
//                        واجهة اختيار المدارس
// ===================================================================
class SchoolSelectionView extends ConsumerWidget {
  const SchoolSelectionView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final schoolsAsync = ref.watch(mySchoolsProvider);

    return schoolsAsync.when(
      data: (schools) {
        if (schools.isEmpty) {
          return _buildEmptyState(
            icon: Icons.school_outlined,
            title: 'لا توجد مدارس',
            message: 'أنت غير مسجل في أي مدرسة بعد',
            actionLabel: 'تحديث',
            onRefresh: () => ref.refresh(mySchoolsProvider.future),
          );
        }
        return RefreshIndicator(
          onRefresh: () => ref.refresh(mySchoolsProvider.future),
          color: AppColors.primary,
          backgroundColor: AppColors.surface,
          strokeWidth: 2.5,
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) =>
                        _buildSchoolCard(context, ref, schools[index]),
                    childCount: schools.length,
                  ),
                ),
              ),
            ],
          ),
        );
      },
      error: (err, _) {
        final failure = asFailure(err);
        if (failure is NetworkFailure) {
          return _buildEmptyState(
            icon: Icons.wifi_off,
            title: 'لا يوجد إنترنت',
            message: 'يرجى الاتصال بالإنترنت ثم إعادة المحاولة',
            actionLabel: 'إعادة المحاولة',
            onRefresh: () => ref.refresh(mySchoolsProvider.future),
          );
        }
        return _buildErrorState(
          message: friendlyFailureMessage(failure),
          onRetry: () => ref.refresh(mySchoolsProvider.future),
        );
      },
      loading: () => _buildLoadingShimmer(),
    );
  }

  Widget _buildSchoolCard(BuildContext context, WidgetRef ref, School school) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        elevation: 2,
        borderRadius: BorderRadius.circular(20),
        color: AppColors.surface,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () =>
              ref.read(selectedSchoolProvider.notifier).selectSchool(school),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha((0.1 * 255).round()),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    Icons.school_rounded,
                    color: AppColors.primary,
                    size: 30,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        school.name,
                        style: AppTextStyles.body.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primaryLight.withAlpha(
                            (0.2 * 255).round(),
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          school.publicCode ?? 'رمز المدرسة',
                          style: AppTextStyles.bodySmall.copyWith(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha((0.1 * 255).round()),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: AppColors.primary,
                    size: 16,
                    textDirection: TextDirection.ltr,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ===================================================================
//                         واجهة عرض الطلاب
// ===================================================================
class StudentListView extends ConsumerStatefulWidget {
  const StudentListView({super.key});

  @override
  ConsumerState<StudentListView> createState() => _StudentListViewState();
}

class _StudentListViewState extends ConsumerState<StudentListView> {
  @override
  void initState() {
    super.initState();

    // ✅ ينفذ بعد أول frame (خارج build)
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final warmDone = ref.read(locationWarmupDoneProvider);
      if (!warmDone) {
        ref.read(locationWarmupDoneProvider.notifier).state = true;
        await ref.read(locationServiceProvider).warmUpHighAccuracy();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final studentsAsync = ref.watch(studentsBySchoolProvider);

    return studentsAsync.when(
      data: (students) {
        if (students.isEmpty) {
          return _buildEmptyState(
            icon: Icons.child_care_outlined,
            title: 'لا يوجد أبناء',
            message: 'لا يوجد أبناء مسجلين في هذه المدرسة',
            actionLabel: 'تحديث',
            onRefresh: () => ref.refresh(mySchoolsProvider.future),
          );
        }
        return RefreshIndicator(
          onRefresh: () => ref.refresh(mySchoolsProvider.future),
          color: AppColors.primary,
          backgroundColor: AppColors.surface,
          strokeWidth: 2.5,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: students.length,
            itemBuilder: (_, index) =>
                StudentAttendanceCard(student: students[index], index: index),
          ),
        );
      },
      error: (err, _) {
        final failure = asFailure(err);
        if (failure is NetworkFailure) {
          return _buildEmptyState(
            icon: Icons.wifi_off,
            title: 'لا يوجد إنترنت',
            message: 'يرجى الاتصال بالإنترنت ثم إعادة المحاولة',
            actionLabel: 'إعادة المحاولة',
            onRefresh: () => ref.refresh(mySchoolsProvider.future),
          );
        }
        return _buildErrorState(
          message: friendlyFailureMessage(failure),
          onRetry: () => ref.refresh(mySchoolsProvider.future),
        );
      },
      loading: () => _buildLoadingShimmer(),
    );
  }
}

// ===================================================================
//                          بطاقة عرض الطالب
// ===================================================================
class StudentAttendanceCard extends ConsumerWidget {
  final Student student;
  final int index;
  final locationService = LocationService();

  StudentAttendanceCard({super.key, required this.student, this.index = 0});

  Map<String, dynamic> _getStatusInfo(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return {
          'color': AppColors.success,
          'icon': Icons.check_circle_rounded,
          'text': 'حاضر',
          'bg': AppColors.success.withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.absent:
        return {
          'color': AppColors.error,
          'icon': Icons.cancel_rounded,
          'text': 'غائب',
          'bg': AppColors.error.withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.late:
        return {
          'color': const Color(0xFFFF8C42),
          'icon': Icons.access_time_filled_rounded,
          'text': 'متأخر',
          'bg': const Color(0xFFFF8C42).withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.requested:
        return {
          'color': AppColors.primary,
          'icon': Icons.send_rounded,
          'text': 'تم إرسال طلب الاستلام',
          'bg': AppColors.primary.withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.atGate:
        return {
          'color': AppColors.primaryDark,
          'icon': Icons.meeting_room_rounded,
          'text': 'عند البوابة',
          'bg': AppColors.primaryDark.withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.delivered:
        return {
          'color': Colors.green.shade700,
          'icon': Icons.cabin,
          'text': 'تم التسليم',
          'bg': Colors.green.withAlpha((0.1 * 255).round()),
        };
      case AttendanceStatus.completed:
        return {
          'color': Colors.teal,
          'icon': Icons.verified_rounded,
          'text': 'مكتمل',
          'bg': Colors.teal.withAlpha((0.1 * 255).round()),
        };
      default:
        return {
          'color': AppColors.textHint,
          'icon': Icons.help_outline_rounded,
          'text': 'غير معروف',
          'bg': AppColors.textHint.withAlpha((0.1 * 255).round()),
        };
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statusInfo = _getStatusInfo(student.status);
    final isOnline = ref.watch(isOnlineProvider);

    final bool canRequestPickup =
        isOnline && student.status == AttendanceStatus.present;

    final bool alreadyRequested =
        student.status == AttendanceStatus.requested ||
        student.status == AttendanceStatus.atGate;

    final bool pickupClosed =
        student.status == AttendanceStatus.delivered ||
        student.status == AttendanceStatus.completed;
    // استخدام provider خاص بكل طالب
    final pickupState = ref.watch(pickupRequestForStudentProvider(student.id));
    final isLoading = pickupState is AsyncLoading;

    // الاستماع للنتيجة
    ref.listen(pickupRequestForStudentProvider(student.id), (previous, next) {
      if (next is AsyncError) {
        final failure = asFailure(next.error ?? 'Unknown error');

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(friendlyFailureMessage(failure)),
            backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      } else if (previous is AsyncLoading && next is AsyncData) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ تم إرسال طلب استلام لـ ${student.name}'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
        ref.invalidate(studentsBySchoolProvider);
        Future.microtask(() => ref.refresh(studentsBySchoolProvider.future));
      }
    });

    Widget buildDisabledAction({
      required IconData icon,
      required String text,
    }) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        decoration: BoxDecoration(
          color: AppColors.textHint.withAlpha((0.08 * 255).round()),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: AppColors.textHint),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                text,
                style: AppTextStyles.bodySmall.copyWith(
                  color: AppColors.textHint,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      );
    }

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (index * 100)),
      curve: Curves.easeOutQuint,
      builder: (context, value, child) {
        return Transform.translate(
          offset: Offset(0, 20 * (1 - value)),
          child: Opacity(opacity: value, child: child),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Material(
          elevation: 2,
          shadowColor: AppColors.textHint.withAlpha((0.1 * 255).round()),
          borderRadius: BorderRadius.circular(20),
          color: AppColors.surface,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    // معلومات الطالب
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            student.name,
                            style: AppTextStyles.body.copyWith(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: statusInfo['bg'],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  statusInfo['icon'],
                                  size: 14,
                                  color: statusInfo['color'],
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  statusInfo['text'],
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: statusInfo['color'],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Divider(height: 1, thickness: 0.5),
                ),

                if (!isOnline) ...[
                  buildDisabledAction(
                    icon: Icons.wifi_off_rounded,
                    text: 'لا يوجد إنترنت',
                  ),
                ] else if (pickupClosed) ...[
                  buildDisabledAction(
                    icon: Icons.verified_rounded,
                    text: 'تم إغلاق الطلب (تم التسليم)',
                  ),
                ] else if (alreadyRequested) ...[
                  buildDisabledAction(
                    icon: Icons.hourglass_top_rounded,
                    text: student.status == AttendanceStatus.atGate
                        ? 'الطالب عند البوابة'
                        : 'تم إرسال الطلب بالفعل',
                  ),
                ] else if (student.status == AttendanceStatus.present) ...[
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: isLoading
                          ? null
                          : () async {
                              ref
                                  .read(
                                    pickupRequestForStudentProvider(
                                      student.id,
                                    ).notifier,
                                  )
                                  .sendRequest();
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: AppColors.onPrimary,
                        disabledBackgroundColor: AppColors.textHint.withAlpha(
                          (0.3 * 255).round(),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        elevation: 0,
                      ),
                      child: isLoading
                          ? const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Text('جاري الإرسال...'),
                              ],
                            )
                          : const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.send_rounded, size: 18),
                                SizedBox(width: 8),
                                Text('طلب استلام الآن'),
                              ],
                            ),
                    ),
                  ),
                ] else ...[
                  buildDisabledAction(
                    icon: Icons.info_outline_rounded,
                    text: 'لا يمكن طلب الاستلام حسب حالة الطالب الحالية',
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ===================================================================
//                      ويدجتس مساعدة (Helpers)
// ===================================================================

Widget _buildEmptyState({
  required IconData icon,
  required String title,
  required String message,
  required String actionLabel,
  required VoidCallback onRefresh,
}) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primaryLight.withAlpha((0.2 * 255).round()),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              size: 64,
              color: AppColors.primary.withAlpha((0.5 * 255).round()),
            ),
          ),
          const SizedBox(height: 24),
          Text(title, style: AppTextStyles.heading2),
          const SizedBox(height: 8),
          Text(
            message,
            style: AppTextStyles.bodySmall,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: onRefresh,
            icon: const Icon(Icons.refresh_rounded, size: 18),
            label: Text(actionLabel),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: AppColors.onPrimary,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _buildErrorState({
  required String message,
  required VoidCallback onRetry,
}) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.error.withAlpha((0.1 * 255).round()),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.error_outline_rounded,
              size: 64,
              color: AppColors.error,
            ),
          ),
          const SizedBox(height: 24),
          Text(message, style: AppTextStyles.heading2),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('إعادة المحاولة'),
          ),
        ],
      ),
    ),
  );
}

Widget _buildLoadingShimmer() {
  return ListView.builder(
    padding: const EdgeInsets.all(16),
    itemCount: 3,
    itemBuilder: (context, index) {
      return Container(
        margin: const EdgeInsets.only(bottom: 16),
        height: 100,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.textHint.withAlpha((0.1 * 255).round()),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight.withAlpha((0.3 * 255).round()),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 16,
                      decoration: BoxDecoration(
                        color: AppColors.primaryLight.withAlpha(
                          (0.3 * 255).round(),
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      width: 100,
                      height: 12,
                      decoration: BoxDecoration(
                        color: AppColors.primaryLight.withAlpha(
                          (0.3 * 255).round(),
                        ),
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Future<void> showLogoutConfirmation(BuildContext context, WidgetRef ref) async {
  final bool? confirm = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return AlertDialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
        contentPadding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),

        // ===== العنوان مع أيقونة =====
        title: Row(
          children: const [
            Icon(Icons.logout_rounded, color: Colors.redAccent),
            SizedBox(width: 10),
            Text(
              'تسجيل الخروج',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ],
        ),

        // ===== المحتوى =====
        content: const Text(
          'سيتم إنهاء جلستك الحالية ولن تصلك إشعارات حتى تقوم بتسجيل الدخول مرة أخرى.\n\nهل ترغب بالمتابعة؟',
          style: TextStyle(height: 1.4),
        ),

        // ===== الأزرار في صف واحد بنفس الحجم =====
        actions: [
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context, false),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text('إلغاء'),
                ),
              ),
              const SizedBox(width: 8), // مسافة بين الزرين
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    foregroundColor: Colors.white,
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text(
                    'تسجيل الخروج',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ],
      );
    },
  );

  // ===== تنفيذ الخروج =====
  if (confirm == true) {
    await ref.read(authStateProvider.notifier).logout();

    if (context.mounted) {
      context.go('/login');
    }
  }
}
